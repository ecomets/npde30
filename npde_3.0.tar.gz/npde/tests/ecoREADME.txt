TODO: 
- check all test functions in the oldtest folder (testthat files created when working on npde3.0) and update with the new package
